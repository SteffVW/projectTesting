﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opdracht_testing_steffvanweereld
{
    public class Amount
    {
        public double amount {  get; set; }
    }
}
