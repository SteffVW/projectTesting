﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Opdracht_testing_steffvanweereld
{
    public class BudgetHelper: IBudgetHelper
    {
        private double budget = 100;

        private string budgetUrl;

        public string BudgetUrl
        {
            get { return budgetUrl; }
            set { budgetUrl = value; }
        }
        private string amountUrl;

        public string AmountUrl
        {
            get { return amountUrl; }
            set { amountUrl = value; }
        }


        public double GetBudget()
        {
            return budget;
        }
        public double UpdateBudget(double amount)
        {
            return budget - amount;
        }
        public void BlockCard()
        {
            throw new NotImplementedException();
        }
        public double GetAmount()
        {
            string jsonPath = "amount.json";

            string jsonContent = File.ReadAllText(jsonPath);

            var jsonDocument = JsonDocument.Parse(jsonContent);

            return jsonDocument.RootElement.GetProperty("amount").GetDouble();
        }
    }
}
